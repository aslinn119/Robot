Roban 统一接口规范 1.0

先阅读 docs/TEAM_INTERFACE.md。A/B/C/D 按本规范开发，不再分别设计接口路径。
contracts/protocol_v1.schema.json 为消息格式约束。
contracts/examples_v1.json 是完整命令和回执样例，编号及内容均为模拟。
config/interface.example.json 仅填写实际部署地址与自身模块配置，令牌从环境变量读取。

本包只有规范、Schema 和样例，不包含已运行的 8780 服务或模型/硬件实现。
格式校验不能代替业务时序、权限和实机验收。已有本地 v0.4 接口需由 C 适配。
